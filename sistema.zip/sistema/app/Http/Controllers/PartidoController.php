<?php

namespace App\Http\Controllers;

use App\Models\Partido;
use Illuminate\Http\Request;

class PartidoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $datos['partidos']=Partido::paginate(5);
        return view('partido.index',$datos );
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('partido.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //

        $campos=[
            'EquipoLocal'=>'required|string|max:100',
            'ResultadoLocal'=>'required|integer|max:100',
            'ResultadoVisitante'=>'required|integer|max:100',
            'EquipoVisitante'=>'required|string|max:100',

        ];
        $mensaje=[
            'required'=>'El :attribute es requerido'

        ];

        $this->validate($request, $campos, $mensaje);

        $datosPartido = request()->except('_token');


        Partido::insert($datosPartido);

        return redirect('partido')->with('mensaje','Partido agregado con exito');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Partido  $partido
     * @return \Illuminate\Http\Response
     */
    public function show(Partido $partido)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Partido  $partido
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $partido=Partido::findOrFail($id);
        return view('partido.edit', compact('partido'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Partido  $partido
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $campos=[
            'EquipoLocal'=>'required|string|max:100',
            'ResultadoLocal'=>'required|integer|max:100',
            'ResultadoVisitante'=>'required|integer|max:100',
            'EquipoVisitante'=>'required|string|max:100',

        ];
        $mensaje=[
            'required'=>'El :attribute es requerido',

        ];

        $this->validate($request, $campos, $mensaje);

        //
        $datosPartido = request()->except(['_token','_method']);


        Partido::where('id','=',$id)->update($datosPartido);
        $partido=Partido::findOrFail($id);

        return redirect('partido')->with('mensaje','Partido modificado');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Partido  $partido
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $partido=Partido::findOrFail($id);

            Partido::destroy($id);


        return redirect('partido')->with('mensaje','Partido borrado');
    }
}
