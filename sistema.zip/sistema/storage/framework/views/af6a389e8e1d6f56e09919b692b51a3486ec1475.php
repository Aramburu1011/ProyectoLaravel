<?php $__env->startSection('content'); ?>
<div class="container">


    <?php if(Session::has('mensaje')): ?>
    <div class="alert alert-success alert-dismissible" role="alert">
        <?php echo e(Session::get('mensaje')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="ture">&times;</span>
        </button>
    </div>
    <?php endif; ?> 
<br>
<h1 style="text-align:center;">Los partidos de La Liga Santander</h1>
<br>
<table class="table table-light">
    <thead class="thead-light" style="text-align: center;">
        <tr>
            <th>#</th>
            <th>Equipo Local</th>
            <th>Resultado Local</th>
            <th></th>
            <th>Resultado Visitante</th>
            <th>Equipo Visitante</th>
            <th>Acciones</th>
        </tr>
    </thead>

    <tbody style="text-align: center;">
        <?php $__currentLoopData = $partidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($partido->id); ?></td>
            <td><?php echo e($partido->EquipoLocal); ?></td>
            <td><?php echo e($partido->ResultadoLocal); ?></td>
            <td>-</td>
            <td style="text-align: center;"><?php echo e($partido->ResultadoVisitante); ?></td>
            <td><?php echo e($partido->EquipoVisitante); ?></td>
            <td>
            
            <a href="<?php echo e(url('/partido/'.$partido->id.'/edit')); ?>" class="btn btn-warning" >
                    Editar 
            </a>
            | 
            
            <form action="<?php echo e(url('/partido/'.$partido->id )); ?>" class="d-inline" method="post">
            <?php echo csrf_field(); ?>
            <?php echo e(method_field('DELETE')); ?>

            <input class="btn btn-danger" type="submit" onclick="return confirm('¿Quieres borrar?')" value="Borrar">

            </form>
            
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </tbody>

</table>
<div class="row">
    <div class="col-10">
    
        <?php echo $partidos->links(); ?>

    </div class="col-2">
    <div>
        <a style="text-align: left;" href="<?php echo e(url('partido/create')); ?>" class="btn btn-success" > Registrar nuevo partido </a>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/partido/index.blade.php ENDPATH**/ ?>