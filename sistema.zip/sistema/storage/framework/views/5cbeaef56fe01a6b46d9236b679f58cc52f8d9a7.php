<h1><?php echo e($modo); ?> partido</h1>

<?php if(count($errors)>0): ?>

    <div class="alert alert-danger" role="alert">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li> <?php echo e($error); ?> </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

   

<?php endif; ?>

<div class="form-group">

<label for="EquipoLocal"> Equipo Local </label>
<select  class="form-control" name="EquipoLocal" 
value="<?php echo e(isset($partido->EquipoLocal)?$partido->EquipoLocal:old('EquipoLocal')); ?>" id="EquipoLocal">
    <option value="Alaves"> Alavés </option>
    <option value="Athletic"> Athletic </option>
    <option value="Atletico"> Atlético </option>
    <option value="Barcelona"> Barcelona </option>
    <option value="Betis"> Betis </option>
    <option value="Cadiz"> Cádiz </option>
    <option value="Celta"> Celta </option>
    <option value="Eibar"> Eibar </option>
    <option value="Elche"> Elche </option>
    <option value="Getafe"> Getafe </option>
    <option value="Granada"> Granada </option>
    <option value="Huesca"> Huesca </option>
    <option value="Levante"> Levante </option>
    <option value="Osasuna"> Osasuna </option>
    <option value="RSociedad"> R.Sociedad </option>
    <option value="RealMadrid "> Real Madrid </option>
    <option value="RealValladolid"> Real Valladolid </option>
    <option value="Sevilla"> Sevilla </option>
    <option value="Valencia"> Valencia </option>
    <option value="Villarreal"> Villarreal </option>
</select>
</div>

<div class="form-group">

<label for="ResultadoLocal"> Resultado Local </label>
<input type="number" class="form-control" name="ResultadoLocal" 
value="<?php echo e(isset($partido->ResultadoLocal)?$partido->ResultadoLocal:old('ResultadoLocal')); ?>" id="ResultadoLocal">

</div>

<div class="form-group">

<label for="ResultadoVisitante"> Resultado Visitante </label>
<input type="number" class="form-control" name="ResultadoVisitante" 
value="<?php echo e(isset($partido->ResultadoVisitante)?$partido->ResultadoVisitante:old('ResultadoVisitante')); ?>" id="ResultadoVisitante">

</div>

<div class="form-group">

<label for="EquipoVisitante"> Equipo Visitante </label>
<select class="form-control" name="EquipoVisitante" 
value="<?php echo e(isset($partido->EquipoVisitante)?$partido->EquipoVisitante:old('EquipoVisitante')); ?>" id="EquipoVisitante">
    <option value="Alaves"> Alavés </option>
    <option value="Athletic"> Athletic </option>
    <option value="Atletico"> Atlético </option>
    <option value="Barcelona"> Barcelona </option>
    <option value="Betis"> Betis </option>
    <option value="Cadiz"> Cádiz </option>
    <option value="Celta"> Celta </option>
    <option value="Eibar"> Eibar </option>
    <option value="Elche"> Elche </option>
    <option value="Getafe"> Getafe </option>
    <option value="Granada"> Granada </option>
    <option value="Huesca"> Huesca </option>
    <option value="Levante"> Levante </option>
    <option value="Osasuna"> Osasuna </option>
    <option value="RSociedad"> R.Sociedad </option>
    <option value="RealMadrid "> Real Madrid </option>
    <option value="RealValladolid"> Real Valladolid </option>
    <option value="Sevilla"> Sevilla </option>
    <option value="Valencia"> Valencia </option>
    <option value="Villarreal"> Villarreal </option>    
</select>
</div>

<input class="btn btn-success" type="submit" value="<?php echo e($modo); ?> datos">

<a class="btn btn-primary" href="<?php echo e(url('partido/')); ?>"> Regresar </a>

<br><?php /**PATH /var/www/resources/views/partido/form.blade.php ENDPATH**/ ?>