
<h1><?php echo e($modo); ?> empleado</h1>

<?php if(count($errors)>0): ?>

    <div class="alert alert-danger" role="alert">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li> <?php echo e($error); ?> </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

   

<?php endif; ?>

<div class="form-group">

<label for="Nombre"> Nombre </label>
<input type="text" class="form-control" name="Nombre" 
value="<?php echo e(isset($empleado->Nombre)?$empleado->Nombre:old('Nombre')); ?>" id="Nombre">
</div>

<div class="form-group">

<label for="PrimerApellido"> Primer Apellido </label>
<input type="text" class="form-control" name="PrimerApellido" 
value="<?php echo e(isset($empleado->PrimerApellido)?$empleado->PrimerApellido:old('PrimerApellido')); ?>" id="PrimerApellido">

</div>

<div class="form-group">

<label for="SegundoApellido"> Segundo Apellido </label>
<input type="text" class="form-control" name="SegundoApellido" 
value="<?php echo e(isset($empleado->SegundoApellido)?$empleado->SegundoApellido:old('SegundoApellido')); ?>" id="SegundoApellido">

</div>

<div class="form-group">

<label for="Correo"> Correo </label>
<input type="text" class="form-control" name="Correo" 
value="<?php echo e(isset($empleado->Correo)?$empleado->Correo:old('Correo')); ?>" id="Correo">

</div>

<div class="form-group">

<label for="Foto">  </label>
<?php if(isset($empleado->Foto)): ?>
<img class="img-thumbnail img-fluid" src="<?php echo e(asset('storage').'/'.$empleado->Foto); ?>" width="100" alt="">
<?php endif; ?>
<input type="file" class="form-control" name="Foto" value="" id="Foto">

</div>

<input class="btn btn-success" type="submit" value="<?php echo e($modo); ?> datos">

<a class="btn btn-primary" href="<?php echo e(url('empleado/')); ?>"> Regresar </a>

<br><?php /**PATH /var/www/resources/views/empleado/form.blade.php ENDPATH**/ ?>