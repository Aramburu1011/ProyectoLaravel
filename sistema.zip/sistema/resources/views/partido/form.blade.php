<h1>{{ $modo }} partido</h1>

@if(count($errors)>0)

    <div class="alert alert-danger" role="alert">
        <ul>
            @foreach( $errors->all() as $error)
                <li> {{ $error }} </li>
            @endforeach
        </ul>
    </div>

   

@endif

<div class="form-group">

<label for="EquipoLocal"> Equipo Local </label>
<select  class="form-control" name="EquipoLocal" 
value="{{ isset($partido->EquipoLocal)?$partido->EquipoLocal:old('EquipoLocal') }}" id="EquipoLocal">
    <option value="Alaves"> Alavés </option>
    <option value="Athletic"> Athletic </option>
    <option value="Atletico"> Atlético </option>
    <option value="Barcelona"> Barcelona </option>
    <option value="Betis"> Betis </option>
    <option value="Cadiz"> Cádiz </option>
    <option value="Celta"> Celta </option>
    <option value="Eibar"> Eibar </option>
    <option value="Elche"> Elche </option>
    <option value="Getafe"> Getafe </option>
    <option value="Granada"> Granada </option>
    <option value="Huesca"> Huesca </option>
    <option value="Levante"> Levante </option>
    <option value="Osasuna"> Osasuna </option>
    <option value="RSociedad"> R.Sociedad </option>
    <option value="RealMadrid "> Real Madrid </option>
    <option value="RealValladolid"> Real Valladolid </option>
    <option value="Sevilla"> Sevilla </option>
    <option value="Valencia"> Valencia </option>
    <option value="Villarreal"> Villarreal </option>
</select>
</div>

<div class="form-group">

<label for="ResultadoLocal"> Resultado Local </label>
<input type="number" class="form-control" name="ResultadoLocal" 
value="{{ isset($partido->ResultadoLocal)?$partido->ResultadoLocal:old('ResultadoLocal') }}" id="ResultadoLocal">

</div>

<div class="form-group">

<label for="ResultadoVisitante"> Resultado Visitante </label>
<input type="number" class="form-control" name="ResultadoVisitante" 
value="{{ isset($partido->ResultadoVisitante)?$partido->ResultadoVisitante:old('ResultadoVisitante') }}" id="ResultadoVisitante">

</div>

<div class="form-group">

<label for="EquipoVisitante"> Equipo Visitante </label>
<select class="form-control" name="EquipoVisitante" 
value="{{ isset($partido->EquipoVisitante)?$partido->EquipoVisitante:old('EquipoVisitante') }}" id="EquipoVisitante">
    <option value="Alaves"> Alavés </option>
    <option value="Athletic"> Athletic </option>
    <option value="Atletico"> Atlético </option>
    <option value="Barcelona"> Barcelona </option>
    <option value="Betis"> Betis </option>
    <option value="Cadiz"> Cádiz </option>
    <option value="Celta"> Celta </option>
    <option value="Eibar"> Eibar </option>
    <option value="Elche"> Elche </option>
    <option value="Getafe"> Getafe </option>
    <option value="Granada"> Granada </option>
    <option value="Huesca"> Huesca </option>
    <option value="Levante"> Levante </option>
    <option value="Osasuna"> Osasuna </option>
    <option value="RSociedad"> R.Sociedad </option>
    <option value="RealMadrid "> Real Madrid </option>
    <option value="RealValladolid"> Real Valladolid </option>
    <option value="Sevilla"> Sevilla </option>
    <option value="Valencia"> Valencia </option>
    <option value="Villarreal"> Villarreal </option>    
</select>
</div>

<input class="btn btn-success" type="submit" value="{{ $modo }} datos">

<a class="btn btn-primary" href="{{ url('partido/')}}"> Regresar </a>

<br>