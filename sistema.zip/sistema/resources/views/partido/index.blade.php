@extends('layouts.app')
@section('content')
<div class="container">


    @if(Session::has('mensaje'))
    <div class="alert alert-success alert-dismissible" role="alert">
        {{ Session::get('mensaje') }}
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="ture">&times;</span>
        </button>
    </div>
    @endif 
<br>
<h1 style="text-align:center;">Los partidos de La Liga Santander</h1>
<br>
<table class="table table-light">
    <thead class="thead-light" style="text-align: center;">
        <tr>
            <th>#</th>
            <th>Equipo Local</th>
            <th>Resultado Local</th>
            <th></th>
            <th>Resultado Visitante</th>
            <th>Equipo Visitante</th>
            <th>Acciones</th>
        </tr>
    </thead>

    <tbody style="text-align: center;">
        @foreach( $partidos as $partido )
        <tr>
            <td>{{ $partido->id }}</td>
            <td>{{ $partido->EquipoLocal }}</td>
            <td>{{ $partido->ResultadoLocal }}</td>
            <td>-</td>
            <td style="text-align: center;">{{ $partido->ResultadoVisitante }}</td>
            <td>{{ $partido->EquipoVisitante }}</td>
            <td>
            
            <a href="{{ url('/partido/'.$partido->id.'/edit') }}" class="btn btn-warning" >
                    Editar 
            </a>
            | 
            
            <form action="{{ url('/partido/'.$partido->id ) }}" class="d-inline" method="post">
            @csrf
            {{ method_field('DELETE') }}
            <input class="btn btn-danger" type="submit" onclick="return confirm('¿Quieres borrar?')" value="Borrar">

            </form>
            
            </td>
        </tr>
        @endforeach
        
    </tbody>

</table>
<div class="row">
    <div class="col-10">
    
        {!! $partidos->links() !!}
    </div class="col-2">
    <div>
        <a style="text-align: left;" href="{{ url('partido/create')}}" class="btn btn-success" > Registrar nuevo partido </a>
    </div>
</div>
</div>
@endsection